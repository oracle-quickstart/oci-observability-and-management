# constants.py

VMWARE_ENTITY_TYPES = {
    "VMware vSphere VM",
    "VMware vSphere ESXi Host",
    "VMware vSphere Cluster",
    "VMware vSphere vCenter",
    "VMware vSphere Data Center",
    "VMware vSphere Data Store"
}


INTERESTED_ENTITY_TYPES = {
    "VirtualMachine": "VMware vSphere VM",
    "HostSystem": "VMware vSphere ESXi Host",
    "ClusterComputeResource": "VMware vSphere Cluster",
    "Datacenter": "VMware vSphere Data Center",
    "Datastore": "VMware vSphere Data Store",
    "Folder": "VMware vSphere vCenter"
}

# OCI API Call Limits
OCI_RATE_LIMIT_CALLS = 100
OCI_RATE_LIMIT_PERIOD = 60

# Entity Cache TTL
CACHE_TTL_SECONDS = 300

